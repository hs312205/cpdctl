## Building a Churn Prediction Model in R

### Load Required Libraries
library("caret")
library("gbm")
library("pmml")
library("httr")
library(rmarkdown)
library("e1071")


### Read the Data

data <- read.csv("assets/rstudio/enhanced_customer_history.csv")

head(data)

str(data)

summary(data)

### Convert churn to factor

data[, 'CHURN'] <- as.factor(data[, 'CHURN'])
levels(data[, 'CHURN']) <- c("not_churn","churn")

### Train & Test Data

smp_size <- floor(0.7*nrow(data))
set.seed(123)
train_ind <- sample(seq_len(nrow(data)),size = smp_size)
train <- data[train_ind,]
test <- data[-train_ind,]

dim(train)
dim(test)

train_y <- factor(train[,10])
train_x <- train[,-10]
test_y <- factor(test[,10])
test_x <- test[,-10]

### Build Churn Prediction Model

gbmGrid <-  expand.grid(interaction.depth = c(1, 3, 6, 9, 10),
                        n.trees = c(20, 50, 100, 200), 
                        shrinkage = 0.1,
                        n.minobsinnode = 10)
gbmControl <- trainControl(
  method = "repeatedcv", 
  number = 3,
  repeats = 5,
  verboseIter = FALSE
)

model <- train(
  y=train_y, 
  x=train_x,
  method = "gbm",
  metric = "Accuracy",
  tuneGrid = gbmGrid,
  trControl = gbmControl,
  verbose = FALSE
)

model

model$bestTune

### Make Predictions

test_preds <- predict(model, newdata = test_x)
head(test_preds)

confusionMatrix(data = test_preds, reference = test_y)

final_model <- model$finalModel

### Saving the Model

model_name <-paste("churn_gbm_model_",sub(" ", "_", Sys.time()), sep="") 
saveRDS(final_model, "gbmmodel.rds")

pmmlmodel <- pmml(final_model, model.name = model_name)
saveXML(pmmlmodel,file = paste(model_name,".xml", sep=""))

## Saving an R Model to WML

### Define Required Variables

wml_url <- "cpd-cpd-instance.apps.cp4d404ugi.cp.fyre.ibm.com"

wml_token <- Sys.getenv("DSX_TOKEN")
project_id <- Sys.getenv("DSX_PROJECT_ID")

pmml_filename  <- "Churn_GBM_Model.xml"

authorization_header <- add_headers("Authorization" = wml_token)

version= "version=2022-02-15"

### Save the Model

#### First we create a model asset in our project to store the model

url <- paste(wml_url, "/ml/v4/models?", version, sep="")

#model_name <- paste("churn_gbm_model_",sub(" ", "_", Sys.time()), sep="") 

metadata <- paste('{
  "name": "', model_name, '",
  "type": "pmml_4.3",
  "software_spec": {"name": "spark-mllib_2.4"},
  "project_id": "',project_id,'"}', sep="")

#project_url<- paste(url,"&project_id=",project_id,sep = "")

response <- POST(url, authorization_header, content_type_json(), body = metadata, config = httr::config(ssl_verifypeer = FALSE, ssl_verifyhost = FALSE))

response$status_code

str(httr::content(response, "parsed"))

model_id <- httr::content(response, "parsed")$metadata$id

#### Next we upload model content
#https://zen-cpd-zen.apps.cpdv35-swat.cpd-daell.com/ml/v4/deployments/3a450d85-d88c-4ad6-bf25-2fd9980e76c6/predictions?version=2021-03-25

url <- paste(wml_url, "/ml/v4/models/", model_id, "/content?content_format=native&project_id=", project_id, "&",version, sep="")

response <- PUT(url, authorization_header, content_type("application/gzip"), body = upload_file(pmml_filename), config = httr::config(ssl_verifypeer = FALSE, ssl_verifyhost = FALSE))

response$status_code

### List Available Models

url <- paste(wml_url, "/ml/v4/models?project_id=", project_id, '&',version, sep="")

response <- GET(url, authorization_header, content_type_json(), config = httr::config(ssl_verifypeer = FALSE, ssl_verifyhost = FALSE))

response$status_code

httr::content(response, "parsed")

## Import local data 
customer_usage_history <- read.csv("~/project_git_repo/JupyterLabs-R-studio-Git/assets/data_asset/customer_usage_history.csv")
View(customer_usage_history)

## Import from the db2 connection
library(RJDBC)
#Then we need to load the DB2 JDBC driver:
jcc = JDBC("com.ibm.db2.jcc.DB2Driver",
           "/user-home/_global_/dbdrivers/jdbc/default/db2jcc4.jar")
#At this point we can establish a database connection:
conn = dbConnect(jcc,
                 "jdbc:db2://9.30.248.108:50000/AIOSDB2",
                 user="db2inst1",
                 password="T3l3phon3passw0rd")
#Let’s run a query (to select all records from the employee table) and #store the results into a data frame:
rs = dbSendQuery(conn, 'SELECT * FROM "AIOSFASTPATHPROCERROR"."AIOSFASTPATHICP-00000000-0000-0000-0000-16486475258054409f8dd5d7f0534c1ea4c0e227ac725ea1ERRORTAB"')
rs2 = dbSendQuery(conn, "SELECT * FROM TEST")

df = fetch(rs, -1)
df2 = fetch(rs2, -1)


